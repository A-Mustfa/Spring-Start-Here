package com.example.Ch9_Ex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch9Ex1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch9Ex1Application.class, args);
	}

}
