package com.example.Ch9_Ex2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch9Ex2Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch9Ex2Application.class, args);
	}

}
