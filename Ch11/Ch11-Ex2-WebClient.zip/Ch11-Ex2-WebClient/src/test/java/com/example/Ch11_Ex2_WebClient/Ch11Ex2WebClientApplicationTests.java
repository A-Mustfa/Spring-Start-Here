package com.example.Ch11_Ex2_WebClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch11Ex2WebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
