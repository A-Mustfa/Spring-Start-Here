package com.example.Ch11_Ex2_WebClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch11Ex2WebClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch11Ex2WebClientApplication.class, args);
	}

}
