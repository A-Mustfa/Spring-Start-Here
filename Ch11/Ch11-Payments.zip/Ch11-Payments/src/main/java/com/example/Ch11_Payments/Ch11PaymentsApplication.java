package com.example.Ch11_Payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch11PaymentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch11PaymentsApplication.class, args);
	}

}
