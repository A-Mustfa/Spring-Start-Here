package com.example.Ch11_Ex1_OpenFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch11Ex1OpenFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ch11Ex1OpenFeignApplication.class, args);
	}

}
