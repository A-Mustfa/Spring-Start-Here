package com.example.Ch11_Ex1_OpenFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch11Ex1OpenFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
