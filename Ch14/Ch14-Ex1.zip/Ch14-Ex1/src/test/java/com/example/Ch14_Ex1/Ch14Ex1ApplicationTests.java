package com.example.Ch14_Ex1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ch14Ex1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
