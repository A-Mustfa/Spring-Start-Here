package com.example.Ch13_Ex1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch13Ex1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch13Ex1Application.class, args);
	}

}
